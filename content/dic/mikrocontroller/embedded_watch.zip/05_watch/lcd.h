#ifndef LCD_H
#define LCD_H

#include "hal.h"

void initLCD(void);
void processLCD(void);

void lcd_clear(void);
void lcd_printf(uint8_t line, uint8_t pos, char *fmt, ...);

extern timer_var_t timer_lcd;

#endif
