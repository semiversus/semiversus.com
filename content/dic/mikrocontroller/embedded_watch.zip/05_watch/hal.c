#include "hal.h"
#include <avr/io.h>
#include <avr/interrupt.h>

#define F_CPU 12000000ul

static uint8_t timer_800us=0;

ISR(TIMER1_COMPA_vect) {
  PORTA^=0x10; // toggle loudspeaker pin
} 

ISR(TIMER0_COMP_vect) {
  timer_800us++;
} 

void initHAL(void) {
  // setting LED port to output and turn off LEDs
  DDRC=0xFF;
  PORTC=0x00;

  // set key port to input and activate pull ups
  DDRA=0x10;
  PORTA=0xEF;

  // initialise timer for sound
  TCCR1A=0x00; // no compare output mode, no waveform generation
  TCCR1B=0x0A; // CTC mode, prescaler 8 (start the timer) 

  TCCR0=0x0B; // CTC mode, prescaler 64 (start the timer)
  OCR0=149; // setting periode time to 800us

  TIMSK=0x02; // disable output compare A interrupt, enable timer 0 overflow interrupt

  sei();
}

void setLEDs(uint8_t value) {
  PORTC=value;
}

void setLED(uint8_t index, uint8_t value) {
  if (value) {
    PORTC|=1<<index;
  }
  else {
    PORTC&=~(1<<index);
  }
}

uint8_t getKeys(void) {
  return (~PINA)&0x0F;
}

uint8_t getKey(uint8_t index) {
  return (PINA&(1<<index))==0;
}

uint8_t keys_pressed=0;

uint8_t getKeysPressed(void) {
  uint8_t keys=keys_pressed;
  keys_pressed=0;
  return keys;
}

uint8_t getKeyPressed(uint8_t index) {
  uint8_t key=keys_pressed&(1<<index);
  keys_pressed&=~(1<<index);
  return key!=0;
}

void playSoundAsync(uint16_t frequency) {
  if (frequency) {
    OCR1A=(F_CPU/16)/frequency-1;
    TIMSK|=0x10; // activate interrupt
  }
  else {
    OCR1A=0;
    TIMSK&=~0x10; // deactive interrupt
  }
}

void processHAL(void) {
  uint8_t index = 0;
  uint8_t keys;
  static uint8_t keys_old=0;
  int32_t timer_interval;

  TIMSK&=~0x02; // disable 800us timer
  if (timer_800us) {
    timer_interval=timer_800us*800;
    while (hal_timers[index] != 0) {
      if ((*(timer_var_t*)hal_timers[index] != 0) && (*(timer_var_t*)hal_timers[index] != TIMER_DISABLED)) {
        if (*(timer_var_t*)(hal_timers[index]) <= timer_interval) {
          *(timer_var_t*)hal_timers[index] = 0;
        }
        else {
          *(timer_var_t*)hal_timers[index] -= timer_interval;
        }
      }
      index++;
    }
    timer_800us=0;
    keys=PINA&0x0F;
    keys_pressed|=(keys_old^keys)&keys_old;
    keys_old=keys;
  }
  TIMSK|=0x02; // enable 800us timer

}
