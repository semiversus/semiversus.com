#include "lcd.h"
#include <avr/io.h>
#include <stdarg.h>

timer_var_t timer_lcd;

#define LCD_WIDTH 8
#define LCD_LINES 2

static char lcd_data[LCD_LINES][LCD_WIDTH];
static uint8_t lcd_init[14]={0x03, 0x03, 0x03, 0x02, 0x02, 0x08, 0x00, 0x0c, 0x00, 0x01, 0x00, 0x06, 0x00, 0x02};
static uint8_t lcd_changed=1;

void initLCD(void) {
	DDRA|=0x50;
	DDRB|=0xE4;
  timer_lcd=TIMER_MSEC(20);
  lcd_clear();
}

void processLCD(void) {
  static uint8_t state=0;
  uint8_t data, line, pos;

  if (timer_lcd) return;

  timer_lcd=TIMER_MSEC(1); // wait at least for 1ms

  if (state<14) {
    data=lcd_init[state];
    if (state==0) timer_lcd=TIMER_MSEC(10);
    else if (state>=12) timer_lcd=TIMER_MSEC(20);
  }
  else if (state==30) {
    data=0x0C;
    timer_lcd=TIMER_MSEC(4);
  }
  else if (state==31) {
    data=0x00;
    timer_lcd=TIMER_MSEC(4);
  }
  else if (state==48) {
    if (lcd_changed) {
      state=12;
    }
    lcd_changed=0;
    timer_lcd=TIMER_MSEC(20);
    return;
  }
  else {
    line=state>31?1:0;
    pos=(state>31?state-32:state-14)/2;
    if (state%2==0) {
      data=0x10|lcd_data[line][pos]>>4;
    }
    else {
      data=0x10|(lcd_data[line][pos]&0x0F);
    }
  }
  state++;

  PORTA=(PORTA&0xAF)|0x10|((data<<2)&0x40); // set EN, set RS
  PORTB=(PORTB&0x1B)|((data<<4)&0xE0)|((data<<2)&0x04);
  PORTA&=~0x10; // reset EN
}

void lcd_clear(void) {
  uint8_t i,j;
  lcd_changed=1;
  for (i=0; i<LCD_LINES; i++) {
    for (j=0; j<LCD_WIDTH; j++) {
      lcd_data[i][j]=' ';
    }
  }
}

static char* bf;
static char buf[12];
static unsigned int num;
static char uc;
static char zs;

static void out(char c) {
    *bf++ = c;
    }

static void outDgt(char dgt) {
	out(dgt+(dgt<10 ? '0' : (uc ? 'A' : 'a')-10));
	zs=1;
    }
	
static void divOut(unsigned int div) {
    unsigned char dgt=0;
	num &= 0xffff; // just for testing the code  with 32 bit ints
	while (num>=div) {
		num -= div;
		dgt++;
		}
	if (zs || dgt>0) 
		outDgt(dgt);
    }	

void lcd_printf(uint8_t line, uint8_t pos, char *fmt, ...)
	{
	va_list va;
	char ch;
	char* p;
	
	va_start(va,fmt);
  lcd_changed=1;
	
	while ((ch=*(fmt++))) {
		if (ch!='%') {
      if (pos<LCD_WIDTH) lcd_data[line][pos++]=ch;
			}
		else {
			char lz=0;
			char w=0;
			ch=*(fmt++);
			if (ch=='0') {
				ch=*(fmt++);
				lz=1;
				}
			if (ch>='0' && ch<='9') {
				w=0;
				while (ch>='0' && ch<='9') {
					w=(((w<<2)+w)<<1)+ch-'0';
					ch=*fmt++;
					}
				}
			bf=buf;
			p=bf;
			zs=0;
			switch (ch) {
				case 0: 
					goto abort;
				case 'u':
				case 'd' : 
					num=va_arg(va, unsigned int);
					if (ch=='d' && (int)num<0) {
						num = -(int)num;
						out('-');
						}
					divOut(10000);
					divOut(1000);
					divOut(100);
					divOut(10);
					outDgt(num);
					break;
				case 'x': 
				case 'X' : 
				    uc= ch=='X';
					num=va_arg(va, unsigned int);
					divOut(0x1000);
					divOut(0x100);
					divOut(0x10);
					outDgt(num);
					break;
				case 'c' : 
					out((char)(va_arg(va, int)));
					break;
				case 's' : 
					p=va_arg(va, char*);
					break;
				case '%' :
					out('%');
				default:
					break;
				}
			*bf=0;
			bf=p;
			while (*bf++ && w > 0)
				w--;
			while (w-- > 0 && pos<LCD_WIDTH) 
        lcd_data[line][pos++]=lz?'0':' ';
			while ((ch= *p++) && pos<LCD_WIDTH)
        lcd_data[line][pos++]=ch;
			}
		}
	abort:;
	va_end(va);
	}

