#ifndef WATCH_H
#define WATCH_H

#include "hal.h"

void initWatch(void);
void processWatch(void);

extern timer_var_t timer_watch;

#endif
