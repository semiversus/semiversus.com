#include "hal.h"
#include "lcd.h"
#include "watch.h"

timer_array_t hal_timers={
  &timer_lcd,
  &timer_watch,
  0
};

int main(void) {
  initHAL();
  initLCD();
  initWatch();
  while(1) {
    processWatch();
    processLCD();
    processHAL();
  }
  return 0;
}
