#include "watch.h"
#include "hal.h"
#include "lcd.h"

timer_var_t timer_watch=0;

uint8_t hour, minute, second, alarm_hour, alarm_minute;
enum watch_state_t {WATCH_RUNNING, ALARM, SET_ALARM_HOUR, SET_ALARM_MINUTE, SET_HOUR, SET_MINUTE} watch_state;

void initWatch(void) {
  hour=12;
  minute=0;
  second=0;
  alarm_hour=12;
  alarm_minute=1;
  timer_watch=0;
  watch_state=WATCH_RUNNING;
}

void processWatch(void) {
  if (watch_state<=3 && timer_watch==0) {
    timer_watch=TIMER_SEC(1);
    second++;
    if (second==60) {
      second=0;
      minute++;
      if (minute==60) {
        minute=0;
        hour++;
        if (hour==24) {
          hour=0;
        }
      }
    }
  }

  switch (watch_state) {
    case WATCH_RUNNING:
      lcd_printf(0,0,"%2d:%02d:%02d", hour, minute, second);
      lcd_printf(1,0,"%2d:%02d",alarm_hour, alarm_minute);
      if (getKeyPressed(0)) watch_state=SET_ALARM_HOUR;
      if (hour==alarm_hour && minute==alarm_minute && second==0) {
        watch_state=ALARM;
      }
      break;
    case SET_ALARM_HOUR:
      lcd_printf(0,0,"  :  :  ");
      lcd_printf(1,0,"%2d:  ",alarm_hour);
      if (getKeyPressed(0)) watch_state=SET_ALARM_MINUTE;
      else if (getKeyPressed(1)) alarm_hour=(alarm_hour+1)%24;
      else if (getKeyPressed(2)) alarm_hour=(alarm_hour+23)%24;
      else if (getKeyPressed(3)) watch_state=WATCH_RUNNING;
      break;
    case SET_ALARM_MINUTE:
      lcd_printf(0,0,"  :  :  ");
      lcd_printf(1,0,"  :%02d",alarm_minute);
      if (getKeyPressed(0)) watch_state=SET_HOUR;
      else if (getKeyPressed(1)) alarm_minute=(alarm_minute+1)%60;
      else if (getKeyPressed(2)) alarm_minute=(alarm_minute+59)%60;
      else if (getKeyPressed(3)) watch_state=WATCH_RUNNING;
      break;
    case SET_HOUR:
      lcd_printf(0,0,"%2d:  :  ",hour);
      lcd_printf(1,0,"  :  ");
      if (getKeyPressed(0)) watch_state=SET_MINUTE;
      else if (getKeyPressed(1)) hour=(hour+1)%24;
      else if (getKeyPressed(2)) hour=(hour+23)%24;
      else if (getKeyPressed(3)) watch_state=WATCH_RUNNING;
      break;
    case SET_MINUTE:
      lcd_printf(0,0,"  :%02d:  ",minute);
      lcd_printf(1,0,"  :  ");
      if (getKeyPressed(0)) watch_state=SET_ALARM_HOUR;
      else if (getKeyPressed(1)) minute=(minute+1)%60;
      else if (getKeyPressed(2)) minute=(minute+59)%60;
      else if (getKeyPressed(3)) watch_state=WATCH_RUNNING;
      break;
    case ALARM:
      lcd_printf(0,0,"ALARM!!!");
      if (getKeyPressed(0)) {
        watch_state=WATCH_RUNNING;
      }
      break;
    default:
      break;
  }
}

