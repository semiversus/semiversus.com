#ifndef HAL_H
#define HAL_H

#include <stdint.h>

void initHAL(void);
void processHAL(void);

// LED Port
void setLEDs(uint8_t value);
void setLED(uint8_t index, uint8_t value);

// Keys
uint8_t getKeys(void);
uint8_t getKey(uint8_t index);
uint8_t getKeysPressed(void);
uint8_t getKeyPressed(uint8_t index);

// Sound
void playSoundAsync(uint16_t frequency);

// Timer
typedef uint32_t timer_var_t;
typedef timer_var_t * const timer_array_t[];
extern timer_array_t hal_timers;

#define TIMER_DISABLED (timer_var_t)-1
#define TIMER_MSEC(v) ((v)*1000ul)
#define TIMER_SEC(v) ((v)*1000000ul)
#define TIMER_MINUTE(v) ((v)*60000000ul)

#endif
