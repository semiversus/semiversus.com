def calculate_volume(a, b, c):
    """ Calculates volume of the given object

    :param a: length of first side of the box
    :param b: length of second side of the box
    :param c: length of third side of the bx
    :returns: volume of the object (with 3 digits accuracy)
    """
    diameter_sphere = min(a, b, c)
    volume_sphere = 4/3 * 3.1415 * (diameter_sphere / 2) ** 3
    volume_cuboid = a * b * c

    return volume_cuboid + (volume_sphere / 2)

if __name__ == '__main__':
    print(calculate_volume(6, 7, 5))
