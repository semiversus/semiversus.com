def replace_vocals(s, vocal):
    """ Replaces all vocals with the given vocal
    >>> replace_vocals('Drei Chinesen mit dem Kontrobass', 'a')
    'Draa Chanasan mat dam Kantrabass'
    """
    for v in 'aeiou':
        s = s.replace(v, vocal)
    return s

# Andere Lösungsvariante:
def replace_vocals2(s, vocal):
    """ Replaces all vocals with the given vocal
    >>> replace_vocals2('Drei Chinesen mit dem Kontrobass', 'a')
    'Draa Chanasan mat dam Kantrabass'
    """
    result = ''

    for letter in s:
        if letter in 'aeiou':
            result += vocal
        else:
            result += letter

    return result


if __name__ == '__main__':
    import doctest
    doctest.testmod()
