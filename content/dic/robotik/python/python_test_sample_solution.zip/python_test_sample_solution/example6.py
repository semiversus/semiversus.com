""" Count the laps of people. User writes the name of the person passing
by the finish line. After each input a result should be presented.

Example:
Name: Jonas
Jonas: 1
Name: Paul
Jonas: 1
Paul: 1
Name: Jonas
Jonas: 2
Paul: 1
Name: Herbert
Jonas: 2
Paul: 1
Herbert: 1
Name: Paul
Jonas: 2
Paul: 2
Herbert: 1
"""

def main():
    lap_dict = dict()  # dictionary with name as keys and laps as values

    while True:
        name = input('Name: ')

        if name in lap_dict:
            lap_dict[name] += 1
        else:
            lap_dict[name] = 1

        for name, laps in lap_dict.items():
            print('%s: %d' % (name, laps))


if __name__ == '__main__':
    main()
