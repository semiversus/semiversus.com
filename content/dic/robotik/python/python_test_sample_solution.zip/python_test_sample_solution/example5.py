def print_letterbox(title):
    """ Prints a letterbox looking like the following example:
    >>> print_letterbox('Per aspera ad astra')
    ***********************
    * Per aspera ad astra *
    ***********************
    """
    print('*' * (len(title)+4) )
    print('* ' + title + ' *')
    print('*' * (len(title)+4) )


if __name__ == '__main__':
    import doctest
    doctest.testmod()
