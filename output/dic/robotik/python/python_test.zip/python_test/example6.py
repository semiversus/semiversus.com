""" Count the laps of people. User writes the name of the person passing
by the finish line. After each input a result should be presented.

Example:
Name: Jonas
Jonas: 1
Name: Paul
Jonas: 1
Paul: 1
Name: Jonas
Jonas: 2
Paul: 1
Name: Herbert
Jonas: 2
Paul: 1
Herbert: 1
Name: Paul
Jonas: 2
Paul: 2
Herbert: 1
"""

def main():



if __name__ == '__main__':
    main()
