def replace_vocals(s, vocal):
    """ Replaces all vocals with the given vocal
    >>> replace_vocals('Drei Chinesen mit dem Kontrobass', 'a')
    'Draa Chanasan mat dam Kantrabass'
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()
