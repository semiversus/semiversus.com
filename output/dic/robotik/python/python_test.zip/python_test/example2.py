def calculate_volume(a, b, c):
    """ Calculates volume of the given object

    :param a: length of first side of the box
    :param b: length of second side of the box
    :param c: length of third side of the bx
    :returns: volume of the object (with 3 digits accuracy)
    """

if __name__ == '__main__':
    print(calculate_volume(6, 7, 5))
