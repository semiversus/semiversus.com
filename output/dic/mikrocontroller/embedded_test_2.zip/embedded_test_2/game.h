#ifndef GAME_H
#define GAME_H

#include "hal.h"

void game_init(void);
void game_process(void);

#endif
