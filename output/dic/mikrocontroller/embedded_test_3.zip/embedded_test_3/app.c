#include "app.h"

timer_var_t timer_app;

void app_init(void) {

}

void app_process(void) {

}
