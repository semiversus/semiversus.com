#include "hal.h"

timer_array_t hal_timers={
  0
};

int main(void) {
  initHAL();
  while(1) {
    processHAL();
  }
  return 0;
}
